import scrapy
import json
import datetime
from scrapy_playwright.page import PageMethod



class AutowiniSpider(scrapy.Spider):
    name = "autowini"
    start_urls = ["https://www.autowini.com/Cars/car-search?i_sSearchType=quick&i_sLocationCd=C1570"]

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url = url,
                meta={"playwright": True, "playwright_include_page": True},
            )

    async def close_context_on_error(self, failure):
        page = failure.request.meta["playwright_page"]
        await page.context.close()

    async def parse(self, response):

        # # Traverse product links
        # product_links = response.xpath("//ul[@class='listBox']/li/a/@href").getall()
        # for link in product_links:
        #     yield response.follow(
        #         link,
        #         callback=self.detail,
        #         errback=self.close_context_on_error,
        #         meta={
        #             "playwright": True,
        #             "playwright_include_page": True,
        #             "playwright_context": link,
        #         },
        #     )

        current_page = response.xpath("//table[@summary='listing']//td/strong/span/text()").getall()[0]
        pagination = response.xpath("//table[@summary='listing']//td/a/span/text()").getall()
        for i in range(len(pagination)):
            if str(int(current_page) + 1) == pagination[i]:

                page = response.meta["playwright_page"]
                await page.evaluate("window.scrollTo(0, document.querySelector('.searchPageBox table[summary=listing]').offsetTop)")
                # await page.wait_for_selector(f"//td[@data-tryxpath-element]")
                await page.wait_for_timeout(1000000)
                await page.click(selector=f"//td[@data-tryxpath-element][{int(pagination[i]) + 2}]")
                await page.screenshot(path=f"example{int(current_page) + 1}.png", full_page=True)
                # await page.wait_for_selector(f"//table[@summary='listing']//td[{int(pagination[i]) + 2}]")
                print("======", str(int(current_page) + 2))
                await page.close()

                # yield scrapy.Request(
                #     url=response.url,
                #     callback=self.test,
                #     errback=self.close_context_on_error,
                #     meta={
                #         "playwright": True,
                #         "playwright_include_page": True,
                #         "playwright_context": f"page{int(current_page) + 1}",
                #     },
                #     # meta=dict(
                #     #     playwright=True,
                #     #     playwright_include_page=True,
                #     #     playwright_page=response.meta["playwright_page"],
                #         # playwright_page_methods={
                #         #     "evaluate": PageMethod("evaluate", "window.scrollBy(0, document.body.scrollHeight)"),
                #         #     "wait_for_selector": PageMethod("wait_for_selector", "//table[@summary='listing']"),
                #         #     "wait_for_timeout": PageMethod("wait_for_timeout", 5000),
                #         #     "screenshot": PageMethod("screenshot", path=f"example{int(current_page) + 1}.png"),
                #         #
                #         # }
                #         # playwright_page_methods=[
                #         #     PageMethod("evaluate", "window.scrollBy(0, document.body.scrollHeight)"),
                #         #     PageMethod("wait_for_selector", "//table[@summary='listing']"),
                #         #     PageMethod("wait_for_timeout", 5000),
                #         #     # PageMethod("click", selector=f"//table[@summary='listing']//td[{int(pagination[i]) + 2}]"),
                #         #     PageMethod("screenshot", path=f"example{int(current_page) + 1}.png")
                #         # ]
                #     # )
                # )

    async def test(self, response):
        page = response.meta["playwright_page"]
        await page.screenshot(path=f"example.png")
        await page.context.close()  # close the context
        await page.close()


    async def detail(self, response):
        output = {}
        page = response.meta["playwright_page"]

        # Form containing the required data
        form_data_th = response.xpath("//div[@class='infoArea']/table//tr/th/text()").getall()
        form_data_td = response.xpath("//div[@class='infoArea']/table//tr/td/text()").getall()
        form_data_td = [value for value in form_data_td if value != '']

        # Get form data circularly
        for i in range(len(form_data_th)):
            if 'vin number' in form_data_th[i].lower():
                output["vin"] = form_data_td[i].strip()

            elif form_data_th[i].strip().lower() == 'model':
                output["model"] = form_data_td[i].replace('\n', '').replace(' ', '').strip()

            elif 'year' in form_data_th[i].lower() or form_data_th[i].strip() == 'Model Year':
                year = form_data_td[i]
                if year:
                    output["year"] = int(year.strip())

            elif 'transmission' in form_data_th[i].lower():
                output["transmission"] = form_data_td[i].strip()

            elif 'engine power' in form_data_th[i].lower():
                # Split data and units
                output["engine_displacement_value"] = form_data_td[i].strip()
                if len(form_data_td[i].strip().split(" ")[1]) > 1:
                    output["engine_displacement_units"] = form_data_td[i].strip().split(" ")[1]

            elif 'fuel' in form_data_th[i].lower():
                output["fuel"] = form_data_td[i].strip()

            elif 'location' in form_data_th[i].lower():
                output["country"] = form_data_td[i].strip()

        output["ac_installed"] = 0
        output["tpms_installed"] = 0
        output["scraped_date"] = datetime.datetime.isoformat(datetime.datetime.today())
        output["scraped_from"] = "autowini"
        output["scraped_listing_id"] = response.url.split("/cars-detail")[0].split("-")[-1]
        output["vehicle_url"] = response.url
        output["city"] = response.xpath("//em[@class='fob']/text()").getall()[0].split(",")[1].strip()

        price = response.xpath(
            "//p[@class='discountPrice red']/text() | //div[@class='price']//strong[@id='itemBisPrice']/text()").getall()[0]
        price = float(price.strip().replace(",", ''))
        output["price_retail"] = price
        output["price_wholesale"] = price
        output["currency"] = response.xpath(
            "//p[@class='discountPrice red']/i/text() | //div[@class='price']//strong[@id='itemBisPrice']/span/text()").getall()[
            0]

        output["picture_list"] = json.dumps(response.xpath("//div[@class='thumbWrap itemCar']/ul/li/a/img/@src").getall())

        await page.context.close()  # close the context
        await page.close()

        yield output

