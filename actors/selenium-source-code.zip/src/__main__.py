import asyncio
import logging

import json
import apify

handler = logging.StreamHandler()

apify_client_logger = logging.getLogger('apify_client')
apify_client_logger.setLevel(logging.INFO)
apify_client_logger.addHandler(handler)

apify_logger = logging.getLogger('apify')
apify_logger.setLevel(logging.DEBUG)
apify_logger.addHandler(handler)

decoded_input = apify.getValue('INPUT').decode()
scrapy_code = json.loads(decoded_input)['scrapyCode']

f = open("./src/main.py", "w")
f.write(scrapy_code)
f.close()

from .main import main

asyncio.run(main())
