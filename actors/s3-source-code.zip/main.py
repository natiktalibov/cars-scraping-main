import os
import json
import boto3
from loguru import logger
from apify import ApifyDataset


def save(task_name,dataset):
    s3 = boto3.client(
        's3',
        region_name=os.environ['AWS_REGION_NAME'],
        aws_access_key_id=os.environ['AWS_KEY'],
        aws_secret_access_key=os.environ['AWS_SECRET'],
    ) # connect GCP bucket

    aws_bucket_path = os.environ['AWS_BUCKET']
    if task_name == 'make' or task_name == 'make-model':
        aws_bucket_path = 'alias-data'
    elif task_name == 'goonetjpn':
        aws_bucket_path = 'vehicle-dimensions'
    elif "dealer" in task_name.lower():
        aws_bucket_path = 'dealer-indexers'

    try:
        logger.info(f"Upload {task_name.split('-')[0]}/{dataset[0]['scraped_date']}.json")
        s3.put_object(Bucket=aws_bucket_path,
                        Body=json.dumps(dataset, ensure_ascii=False),
                        Key=f"{task_name}/{dataset[0]['scraped_date']}.json")
    except Exception as e:
        logger.error(str(e))


def quantity(task_name,dataset):
    if len(dataset) > 800000:
        for i in range(int(len(dataset) / 800000) + 1):
            dataset1 = dataset[i * 800000:(i + 1) * 800000]
            if len(dataset1) > 0:
                save(task_name=task_name, dataset=dataset1)
    else:
        save(task_name=task_name, dataset=dataset)


def main():
    datasets = ApifyDataset()
    
    for dataset, task_name in datasets:
        logger.info(task_name)
        if 'Wikipedia' not in task_name:
            quantity(task_name=task_name, dataset=dataset)

        else:
            if 'Wikipedia-makes' in task_name:
                task_name = 'make'
                quantity(task_name=task_name, dataset=dataset)

            elif 'Wikipedia-models' in task_name:
                task_name = 'make-model'
                quantity(task_name=task_name, dataset=dataset)



if __name__ == '__main__':
    main()
