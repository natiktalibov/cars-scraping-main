import os
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from apify_client import ApifyClient
from loguru import logger


actor_list = ['Scrapy', 'Selenium', "Playwright"]


class ApifyDataset:

    def __init__(self):
        self.client = ApifyClient(os.environ['APIF_TOKEN'])

    def task_info(self):
        task_list = []
        for task in self.client.tasks().list().items:
            # get task id and name
            for actor in actor_list:
                if actor is not None and task['actName'] is not None:
                    if actor.lower().strip() == task['actName'].lower().strip():
                        task_list.append((task['id'], task['name']))
                        break
        return task_list

    def run_info(self):
        run_list = []
        task_list = self.task_info()
        if task_list:
            for task_id, task_name in task_list:
                for run in self.client.task(task_id).runs().list().items:
                    if run and run.get('finishedAt') is not None:
                        # Calculate the time difference of utc+4
                        
                        if (datetime.now(timezone.utc) + relativedelta(hours=4) - (run['finishedAt'] + relativedelta(hours=4))).days < 1:
                            # Get the dataset id whose time difference is less than or equal to 1 day
                            run_list.append((run['defaultDatasetId'], task_name))
        return run_list

    def __iter__(self):
        for dataset_id, task_name in self.run_info():
            
            dataset = self.client.dataset(dataset_id).list_items().items
            if len(dataset) > 0:
                yield dataset, task_name

